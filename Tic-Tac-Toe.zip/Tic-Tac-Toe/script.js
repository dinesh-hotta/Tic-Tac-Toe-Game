const cells = document.querySelectorAll('[data-cell]');
const board = document.getElementById('board');
const statusText = document.getElementById('status');
const restartBtn = document.getElementById('restartBtn');

let currentPlayer = 'X';
let gameActive = true;

// Define all the winning combinations (rows, columns, diagonals)
const winningCombos = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];

// Initialize or restart the game
function startGame() {
  cells.forEach(cell => {
    cell.classList.remove('x', 'o');
    cell.textContent = '';
    // Allow each cell to be clicked only once
    cell.addEventListener('click', handleClick, { once: true });
  });

  // Set the starting player
  currentPlayer = 'X';
  gameActive = true;
  statusText.textContent = "Player X's Turn";
}

function handleClick(e) {
  if (!gameActive) return;
  const cell = e.target;
  const mark = currentPlayer.toLowerCase();
  cell.classList.add(mark);
  cell.textContent = currentPlayer;

  // Check if the current player has won
  if (checkWin(mark)) {
    statusText.textContent = `Player ${currentPlayer} Wins!`;
    gameActive = false;
  } 
  // Check if the game is a draw
  else if (isDraw()) {
    statusText.textContent = "It's a Draw!";
    gameActive = false;
  } 
  // Switch turns to the next player
  else {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    statusText.textContent = `Player ${currentPlayer}'s Turn`;
  }
}

// Check if the given player has any of the winning combinations
function checkWin(playerClass) {
  return winningCombos.some(combo => {
    return combo.every(index => {
      return cells[index].classList.contains(playerClass);
    });
  });
}

// Check if all cells are filled and no winner (i.e., it's a draw)
function isDraw() {
  return [...cells].every(cell =>
    cell.classList.contains('x') || cell.classList.contains('o')
  );
}

// Add an event listener to restart the game when button is clicked
restartBtn.addEventListener('click', startGame);

startGame();